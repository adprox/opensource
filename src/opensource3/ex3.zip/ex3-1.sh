#!/bin/sh
a=$1
b=$2
c=$3

if (b =+) then
  echo a+c
fi

if (b =-) then
  echo a-c
fi
